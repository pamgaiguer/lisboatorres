"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"

export default function LandingPage() {
  const [formData, setFormData] = useState({
    nome: "",
    sobrenome: "",
    email: "",
    mensagem: "",
    privacidade: false,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    // Aqui você pode adicionar a lógica de envio
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0A2472] via-[#0E3A8C] to-[#0A2472] relative overflow-hidden p-6 md:p-8 lg:p-12">
      <div className="relative z-10 min-h-[calc(100vh-3rem)] md:min-h-[calc(100vh-4rem)] lg:min-h-[calc(100vh-6rem)] flex items-center">
        <div className="w-full max-w-7xl mx-auto grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Form Section */}
          <div className="bg-gray-50 rounded-3xl p-8 md:p-10 shadow-2xl max-w-xl">
            <div className="text-center mb-8">
              <h1 className="text-2xl md:text-3xl font-bold text-[#0A2472] mb-2">Tem um projeto?</h1>
              <p className="text-xl md:text-2xl font-semibold text-[#0E3A8C]">Mande uma mensagem!</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Nome e Sobrenome */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="nome" className="block text-sm font-medium text-gray-700 mb-2">
                    Nome *
                  </label>
                  <Input
                    id="nome"
                    type="text"
                    placeholder="Nome"
                    value={formData.nome}
                    onChange={(e) => setFormData({ ...formData, nome: e.target.value })}
                    required
                    className="w-full bg-white border-gray-200"
                  />
                </div>
                <div>
                  <label htmlFor="sobrenome" className="block text-sm font-medium text-gray-700 mb-2">
                    Sobrenome *
                  </label>
                  <Input
                    id="sobrenome"
                    type="text"
                    placeholder="Sobremnome"
                    value={formData.sobrenome}
                    onChange={(e) => setFormData({ ...formData, sobrenome: e.target.value })}
                    required
                    className="w-full bg-white border-gray-200"
                  />
                </div>
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                  Email *
                </label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="w-full bg-white border-gray-200"
                />
              </div>

              {/* Mensagem */}
              <div>
                <label htmlFor="mensagem" className="block text-sm font-medium text-gray-700 mb-2">
                  Mensagem *
                </label>
                <Textarea
                  id="mensagem"
                  placeholder="Escreva aqui sua mensagem"
                  value={formData.mensagem}
                  onChange={(e) => setFormData({ ...formData, mensagem: e.target.value })}
                  required
                  className="w-full min-h-[120px] resize-none bg-white border-gray-200"
                />
              </div>

              {/* Privacy Checkbox */}
              <div className="flex items-start gap-3">
                <Checkbox
                  id="privacidade"
                  checked={formData.privacidade}
                  onCheckedChange={(checked) => setFormData({ ...formData, privacidade: checked as boolean })}
                  required
                  className="mt-0.5"
                />
                <label htmlFor="privacidade" className="text-sm text-gray-600 leading-tight cursor-pointer">
                  Você concorda com nossa política de privacidade.
                </label>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-full bg-[#2563EB] hover:bg-[#1D4ED8] text-white font-semibold py-6 text-base rounded-lg"
              >
                Enviar
              </Button>
            </form>
          </div>

          {/* Decorative Icon Section */}
          <div className="hidden lg:flex items-center justify-center">
            <div className="w-40 h-40 rounded-full bg-white flex items-center justify-center shadow-xl">
              <svg className="w-24 h-24 text-[#0E3A8C]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="3" strokeWidth="1.5" />
                <circle cx="12" cy="12" r="8" strokeWidth="1.5" />
                <path d="M12 2v4m0 12v4M2 12h4m12 0h4" strokeWidth="1.5" />
                <path
                  d="M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"
                  strokeWidth="1.5"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
